import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-simbolos',
  templateUrl: './simbolos.page.html',
  styleUrls: ['./simbolos.page.scss'],
  standalone: false
})
export class SimbolosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
