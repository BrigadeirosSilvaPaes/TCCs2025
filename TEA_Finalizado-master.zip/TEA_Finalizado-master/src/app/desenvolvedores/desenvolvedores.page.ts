import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-desenvolvedores',
  templateUrl: './desenvolvedores.page.html',
  styleUrls: ['./desenvolvedores.page.scss'],
  standalone: false,
})
export class DesenvolvedoresPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
