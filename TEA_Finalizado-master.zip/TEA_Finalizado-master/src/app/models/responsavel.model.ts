export class Responsavel {
  constructor(
    public nome: string,
    public email: string,
    public senha: string
  ) {}
}