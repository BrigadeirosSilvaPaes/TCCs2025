import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-login',
  templateUrl: './menu-login.page.html',
  styleUrls: ['./menu-login.page.scss'],
  standalone: false
})
export class MenuLoginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
