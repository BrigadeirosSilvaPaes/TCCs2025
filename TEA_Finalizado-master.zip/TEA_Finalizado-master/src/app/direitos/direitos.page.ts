import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-direitos',
  templateUrl: './direitos.page.html',
  styleUrls: ['./direitos.page.scss'],
  standalone: false,
})
export class DireitosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
