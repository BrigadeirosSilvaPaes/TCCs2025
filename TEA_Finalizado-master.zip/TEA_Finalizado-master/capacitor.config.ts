import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'TEA_Finalizado',
  webDir: 'www'
};

export default config;
