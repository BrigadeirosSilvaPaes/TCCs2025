// src/app/tabs/tabs.page.ts (Versão Corrigida)

import { Component, EnvironmentInjector, inject, OnInit } from '@angular/core'; // 👈 Adicionar OnInit
import { Router } from '@angular/router'; // 👈 Importar Router
import { IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { triangle, ellipse, square } from 'ionicons/icons';

@Component({
  selector: 'app-tabs',
  templateUrl: 'tabs.page.html',
  styleUrls: ['tabs.page.scss'],
  imports: [IonTabs, IonTabBar, IonTabButton, IonIcon, IonLabel],
})
export class TabsPage implements OnInit { // 👈 Implementar OnInit
  
  // Usando inject para o Router e EnvironmentInjector
  public environmentInjector = inject(EnvironmentInjector);
  private router = inject(Router); // 👈 Injetar o Router

  constructor() {
    addIcons({ triangle, ellipse, square });
  }

  // 🚨 Adicionar o método ngOnInit para forçar a navegação
  ngOnInit() {
    // Verifica a URL atual. Se estiver em '/tabs' (o path do TabsPage sem sub-rota), 
    // forçamos para a tab1. Isso funciona como uma 'válvula de segurança' 
    // contra falhas de roteamento.
    const currentUrl = this.router.url;
    
    if (currentUrl === '/tabs') {
      // Usamos replaceUrl: true para evitar poluir o histórico do navegador.
      this.router.navigateByUrl('/tabs/tab1', { replaceUrl: true });
    }
  }
}